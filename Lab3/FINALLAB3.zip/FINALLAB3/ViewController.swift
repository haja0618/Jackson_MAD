//
//  ViewController.swift
//  FINALLAB3
//
//  Created by Hannah Jackson on 9/28/16.
//  Copyright © 2016 Hannah Jackson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //outlets and variabels
    
    @IBOutlet weak var inputLength: UITextField!
    @IBOutlet weak var inputWidth: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    
    

    override func viewDidLoad() {
        //load data and redisplay in here when app is FIRST LAUNCHING
        super.viewDidLoad()
    }

    
    //actions and methods
    @IBAction func buttonPressed(sender: AnyObject) {
        if let length=Double(inputLength.text!) {
            resultLabel.text = "\(length)"
            
            if let width = Double(inputWidth.text!){
                resultLabel.text=("\(width)")
                
                let area = length * width
        func updateArea()
        {
            
            
            let areaFormatter = NSNumberFormatter()
                
            areaFormatter.numberStyle=NSNumberFormatterStyle.CurrencyStyle
                
            
            let title = sender.titleForState(.Normal)!
            let text = String(area)
            let styledText = NSMutableAttributedString(string: text)
            let attributes = [
            NSFontAttributeName: UIFont.boldSystemFontOfSize(resultLabel.font.pointSize)
                ]
                let nameRange = (text as NSString).rangeOfString(title)
                styledText.setAttributes(attributes, range: nameRange)
            
                
        
                
                }
            resultLabel.text = "The area is \(area)"
            }
            
        }
        
        
        
        
    }

}

