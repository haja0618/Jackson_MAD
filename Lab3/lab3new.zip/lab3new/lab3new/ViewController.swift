//
//  ViewController.swift
//  lab3new
//
//  Created by Hannah Jackson on 9/27/16.
//  Copyright © 2016 Hannah Jackson. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    //UILABELS
    @IBOutlet weak var header: UILabel!
    @IBOutlet weak var lengthTitle: UILabel!
    @IBOutlet weak var widthTitle: UILabel!
    @IBOutlet weak var resultTitle: UILabel!
    @IBOutlet weak var finalResult: UILabel!
    
    //UITEXT
    @IBOutlet weak var LengthAmt: UITextField!
    @IBOutlet weak var WidthAmount: UITextField!
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func updateArea()
    {
        var length:Float // length
        var width:Float // width
        
        if LengthAmt.text!.isEmpty {
            length = 0.0
        } else {
            length = Float(LengthAmt.text!)!
        }
        
        if WidthAmount.text!.isEmpty {
            width = 0.0
        } else {
            width = Float(WidthAmount.text!)!
        }


        let area=width*length
        
        self.updateArea()
        
        }
        

    
    override func viewDidLoad() {
        LengthAmt.delegate=self
        WidthAmount.delegate=self
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view, typically from a nib.
        
        let areaFormatter = NSNumberFormatter()
        
        areaFormatter.numberStyle=NSNumberFormatterStyle.CurrencyStyle
        
        finalResult.text=areaFormatter.stringFromNumber(area)

    }
    
    
    func textFieldDidEndEditing(textField: UITextField) {
        updateArea()
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}



