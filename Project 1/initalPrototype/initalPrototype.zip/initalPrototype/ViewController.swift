//
//  ViewController.swift
//  initalPrototype
//
//  Created by Hannah Jackson on 9/29/16.
//  Copyright © 2016 Hannah Jackson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //outlets

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //actions
    @IBAction func powerButtonPressed(sender: AnyObject) {
    }
    @IBOutlet weak var buttonAPressed: UIButton!
    @IBOutlet weak var buttonBPressed: UIButton!
    @IBOutlet weak var buttonCPressed: UIButton!
    @IBOutlet weak var buttonDPressed: UIButton!
    @IBOutlet weak var buttonEPressed: UIButton!

}

